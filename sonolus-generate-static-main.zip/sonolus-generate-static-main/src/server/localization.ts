import { LocalizationText } from '@sonolus/core'

export type Localize = (text: LocalizationText) => string
